#!/bin/bash
path=~/test/sh/
source ./auto_tar.sh
cd $path
source ./Install_nginx.sh
cd $path
source ./mysql.sh
cd $path
source ./apache.sh
cd $path
source ./php.sh

cd ~/test/tar_gz/
source ./auto_clean.sh

